function  veureMes(){
    var mestext = document.getElementById("mestext");

    mestext.classList.remove("ocult");
    mestext.classList.add("visible");
}