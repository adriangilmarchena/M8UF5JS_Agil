function encesa(bombeta){
   bombeta.src="img/llumon.gif";
}

function apagada(bombeta){
    bombeta.src="img/llumoff.gif";
}

function encesa(bombeta2){
    bombeta2.src="img/llumon.gif";
 }
 
 function apagada(bombeta2){
     bombeta2.src="img/llumoff.gif";
 }

 function encesa(bombeta3){
    bombeta3.src="img/llumon.gif";
 }
 
 function apagada(bombeta3){
     bombeta3.src="img/llumoff.gif";
 }

 function trencar(bombeta){
     bombeta.src="img/llumbreak.gif"
 }

 function trencar(bombeta2){
    bombeta2.src="img/llumbreak.gif"
}

function trencar(bombeta3){
    bombeta3.src="img/llumbreak.gif"
}

