function enviarSalutacio(){
    var nom = document.getElementById("nom").value;
    var cognom = document.getElementById("cognom").value;
    var salutacio = document.getElementById("salutacio");

    salutacio.innerHTML = "HOLA " + nom + " " + cognom + ", GRACIES PER OMPLIR EL FORMULARI";
}
