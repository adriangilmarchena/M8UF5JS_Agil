function comprovar(){
    
    var contrasenya1=document.getElementById("contrasenya1").value;
    var contrasenya2=document.getElementById("contrasenya2").value;
    var contrasenyaLocal = localStorage.getItem('contrasenya');

    if(contrasenya1 == contrasenya2){
        alert("les contrasenyas son correctas.");
    } else{
        alert("les contrasenyas no son correctas.");
    }

    if(contrasenya1 == contrasenyaLocal){
        alert("Pots entrar");
    } else{
        alert("No pots entrar");
    }


}

function guardarDades(){
    //SET = COGER VALOR
    //GET = MOSTRA VALOR

    var nom = document.getElementById('nom').value;
    localStorage.setItem(/*CLAVE*/'nombreUsuario',/*VALOR (VARIABLE)*/nom);
    var cognom = document.getElementById('cognom').value;
    localStorage.setItem('apellidoUsuario',cognom);
    var contrasenya1=document.getElementById("contrasenya1").value;
    localStorage.setItem('contrasenya', contrasenya1);
    var contrasenyaLocal = localStorage.getItem('contrasenya');

    if(contrasenya1 == contrasenyaLocal){
        alert("Login correcte");
    } else{
        alert("Login incorrect");
    }
}

function recuperarDades(){
    var nombreUsuario = localStorage.getItem('nombreUsuario');
    var apellidoUsuario = localStorage.getItem('apellidoUsuario');

    alert(nombreUsuario + ' ' + apellidoUsuario);

}

function esborrarDades(){
    localStorage.removeItem('nombreUsuario');
    localStorage.removeItem('apellidoUsuario');
    localStorage.removeItem('contrasenya');
    
    alert("Dades borradas");
}
