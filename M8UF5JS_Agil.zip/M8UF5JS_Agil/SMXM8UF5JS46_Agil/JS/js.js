function boton(a){
    document.getElementById("calculadora").value+=(a);
}

function calcular(){
    var calculado=document.getElementById("calculadora").value;
    document.getElementById("calculadora").value=eval(calculado);
}

